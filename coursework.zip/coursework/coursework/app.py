from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__,template_folder='template')

# Change this to your secret key (can be anything, it's for extra protection)
app.secret_key = 'name'

# Enter your database connection details below
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'pythonlogin'

# Intialize MySQL
mysql = MySQL(app)


def encrypt(char):
    length = len(char)
    list = []
    for i in char:
        value = ord(i)
        value = value/length
        list.append(value)
    list = str(list)
    return list

def array_merge( first_array, second_array):
    if isinstance( first_array , list) and isinstance( second_array, list):
        return first_array + second_array
    elif isinstance( first_array, dict) and isinstance( second_array, dict):
        return dict (list(first_array.items() ) + list ( second_array.items() ))
    elif isinstance( first_array, set) and isinstance(second_array, set):
        return first_array.union(second_array)
    return False


@app.route('/')
def home():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM featured')
    rows = cursor.fetchall()
    return render_template('index.html',product = rows)

@app.route('/cart')
def cart():
    return render_template('cart.html')
                
@app.route('/proceed')
def proceed():
    return render_template('proceed.html')
    
@app.route('/groceries')
def groceries():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    keyword = 'groceries'
    cursor.execute('SELECT * FROM products WHERE category = %s ',(keyword,))
    rows = cursor.fetchall()
    return render_template('groceries.html',product = rows)

@app.route('/electronics')
def electronics():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    keyword = 'electronics'
    cursor.execute('SELECT * FROM products  WHERE category = %s ',(keyword,))
    rows = cursor.fetchall()
    return render_template('electronics.html',product = rows)

@app.route('/clothing')
def clothing():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    keyword = 'clothing'
    cursor.execute('SELECT * FROM products  WHERE category = %s ',(keyword,))
    rows = cursor.fetchall()
    return render_template('clothing.html',product = rows)

@app.route('/login', methods=['GET','POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        new_password = encrypt(password)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username, new_password,))
        account = cursor.fetchone()
        if account:
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            return redirect(url_for('.home'))
        else:
            msg = 'Incorrect username/password!'
    return render_template('login.html', msg=msg)


@app.route('/register', methods=['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST':
        if 'username' in request.form and 'password' in request.form and 'email' in request.form and 'firstname' in request.form and 'lastname' in request.form:
            username = request.form['username']
            password = request.form['password']
            email = request.form['email']
            firstname = request.form['firstname']
            lastname = request.form['lastname']
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute('SELECT * FROM accounts WHERE username = %s OR email = %s', (username,email,))
            account = cursor.fetchone()
            if account:
                msg = 'Account already exists!'
            elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
                msg = 'Invalid email address!'
            elif not re.match(r'[A-Za-z0-9]+', username):
                msg = 'Username must contain only characters and numbers!'
            elif not username or not password or not email:
                msg = 'Please fill out the form!'
            else:
                cursor.execute('INSERT INTO accounts VALUES (NULL, %s, %s, %s, %s, %s)', (username, firstname, lastname, encrypt(password), email,))
                mysql.connection.commit()
                msg = 'You have successfully registered!'
            return render_template('register.html',msg=msg)

    elif request.method == 'POST':
        msg = 'Please fill out the form!'
    return render_template('register.html', msg=msg)

@app.route('/change-password', methods=['GET', 'POST'])
def password():
    msg=''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'confirmpassword' in request.form:
        username = request.form['username']
        password = request.form['password']
        newpassword = request.form['confirmpassword']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s', (username,))
        account = cursor.fetchone()

        if account:
            if password == newpassword:
                cursor.execute('UPDATE accounts SET password = %s WHERE username = %s',(encrypt(newpassword), username,))
                mysql.connection.commit()
                msg = 'Password Successfully Changed!'
            elif password != newpassword:
                msg = 'Passwords do not match'

    elif request.method == 'POST':
        msg = 'Please fill out the form!'

    return render_template('password.html', msg=msg)

@app.route('/profile')
def profile():
    if 'loggedin' in session:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE id = %s', (session['id'],))
        account = cursor.fetchone()
        return render_template('profile.html', account=account)
    return render_template('login.html')


@app.route('/logout')
def logout():
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   return redirect(url_for('.home'))

@app.route('/search', methods=['GET','POST'])
def search():
    if request.method == 'POST' and 'search' in request.form:
            search = request.form['search']
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute("SELECT * FROM products WHERE name LIKE %s OR price LIKE %s ",("%"+search+"%","%"+search+"%",))
            account = cursor.fetchall()
            return render_template('search.html',account=account)


@app.route('/checkout')
def checkout():
    return render_template('checkout.html')



@app.route('/empty')
def empty_cart():
    try:
        session.pop('cart_item')
        return redirect(url_for('.cart'))
    except Exception as e:
        print(e)


@app.route('/delete/<string:code>')
def delete_product(code):
    try:
        all_total_price = 0
        all_total_quantity = 0
        session.modified = True

        for item in session['cart_item'].items():
            if item[0] == code:
                session['cart_item'].pop(item[0], None)
                if 'cart_item' in session:
                    for key, value in session['cart_item'].items():
                        individual_quantity = int(session['cart_item'][key]['quantity'])
                        individual_price = float(session['cart_item'][key]['total_price'])
                        all_total_quantity = all_total_quantity + individual_quantity
                        all_total_price = all_total_price + individual_price
                break
        if all_total_quantity == 0:
            session.pop('cart_item')
        else:
            session['all_total_quantity'] = all_total_quantity
            session['all_total_price'] = all_total_price

        return redirect(url_for('.cart'))
    except Exception as e:
        print(e)




@app.route('/add-groceries', methods=['POST'])
def add_groceries_to_cart():
    cursor = None

    _quantity = int (request.form['quantity'])
    _code = request.form['code']
    #validate the received values
    if _quantity and _code and request.method == 'POST':

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM products WHERE code=%s", (_code,))
        row = cursor.fetchone()
        a = []
        itemArray = { row['code'] : {'name' : row['name'], 'code' : row['code'], 'quantity' :_quantity, 'price' : row['price'], 'image' : row['image'], 'total_price': _quantity * row['price'] }}

        all_total_price =0
        all_total_quantity = 0

        totalprice = []

        session.modified = True
        new_var = []
        if 'cart_item' in session:
            if row['code'] in session['cart_item']:
                for key,value in session['cart_item'].items():
                    if row['code'] == key:
                        old_quantity = session['cart_item'][key]['quantity']
                        total_quantity = old_quantity + _quantity
                        session['cart_item'][key]['quantity'] = total_quantity
                        session['cart_item'][key]['total_price'] = int(total_quantity * row['price'])

            else:   
                session['cart_item'] = array_merge(session['cart_item'], itemArray)

            for key, value in session['cart_item'].items():
                individual_quantity = int(session['cart_item'][key]['quantity'])
                individual_price = float(session['cart_item'][key]['total_price'])
                all_total_quantity = all_total_quantity + individual_quantity
                all_total_price = all_total_price + individual_price

        else:
            session['cart_item'] = itemArray
            all_total_quantity = all_total_quantity+ _quantity
            all_total_price = all_total_price + _quantity * row['price']

        session['all_total_quantity'] = all_total_quantity
        session['all_total_price'] = all_total_price

        return redirect(url_for('.groceries'))
    else:
        return 'Error while adding item to cart'



@app.route('/add-clothing', methods=['POST'])
def add_clothing_to_cart():
    cursor = None

    _quantity = int (request.form['quantity'])
    _code = request.form['code']
    #validate the received values
    if _quantity and _code and request.method == 'POST':

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM products WHERE code=%s", (_code,))
        row = cursor.fetchone()
        a = []
        itemArray = { row['code'] : {'name' : row['name'], 'code' : row['code'], 'quantity' :_quantity, 'price' : row['price'], 'image' : row['image'], 'total_price': _quantity * row['price'] }}

        all_total_price =0
        all_total_quantity = 0

        totalprice = []

        session.modified = True
        new_var = []
        if 'cart_item' in session:
            if row['code'] in session['cart_item']:
                for key,value in session['cart_item'].items():
                    if row['code'] == key:
                        old_quantity = session['cart_item'][key]['quantity']
                        total_quantity = old_quantity + _quantity
                        session['cart_item'][key]['quantity'] = total_quantity
                        session['cart_item'][key]['total_price'] = int(total_quantity * row['price'])

            else:
                session['cart_item'] = array_merge(session['cart_item'], itemArray)

            for key, value in session['cart_item'].items():
                individual_quantity = int(session['cart_item'][key]['quantity'])
                individual_price = float(session['cart_item'][key]['total_price'])
                all_total_quantity = all_total_quantity + individual_quantity
                all_total_price = all_total_price + individual_price

        else:
            session['cart_item'] = itemArray
            all_total_quantity = all_total_quantity+ _quantity
            all_total_price = all_total_price + _quantity * row['price']

        session['all_total_quantity'] = all_total_quantity
        session['all_total_price'] = all_total_price

        return redirect(url_for('.clothing'))
    else:
        return 'Error while adding item to cart'



@app.route('/add-electronics', methods=['POST'])
def add_electronics_to_cart():
    cursor = None

    _quantity = int (request.form['quantity'])
    _code = request.form['code']
    #validate the received values
    if _quantity and _code and request.method == 'POST':

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM products WHERE code=%s", (_code,))
        row = cursor.fetchone()
        a = []
        itemArray = { row['code'] : {'name' : row['name'], 'code' : row['code'], 'quantity' :_quantity, 'price' : row['price'], 'image' : row['image'], 'total_price': _quantity * row['price'] }}

        all_total_price =0
        all_total_quantity = 0

        totalprice = []

        session.modified = True
        new_var = []
        if 'cart_item' in session:
            if row['code'] in session['cart_item']:
                for key,value in session['cart_item'].items():
                    if row['code'] == key:
                        old_quantity = session['cart_item'][key]['quantity']
                        total_quantity = old_quantity + _quantity
                        session['cart_item'][key]['quantity'] = total_quantity
                        session['cart_item'][key]['total_price'] = int(total_quantity * row['price'])

            else:
                session['cart_item'] = array_merge(session['cart_item'], itemArray)

            for key, value in session['cart_item'].items():
                individual_quantity = int(session['cart_item'][key]['quantity'])
                individual_price = float(session['cart_item'][key]['total_price'])
                all_total_quantity = all_total_quantity + individual_quantity
                all_total_price = all_total_price + individual_price

        else:
            session['cart_item'] = itemArray
            all_total_quantity = all_total_quantity+ _quantity
            all_total_price = all_total_price + _quantity * row['price']

        session['all_total_quantity'] = all_total_quantity
        session['all_total_price'] = all_total_price

        return redirect(url_for('.electronics'))
    else:
        return 'Error while adding item to cart'

if __name__ == '__main__':
    app.run(debug=True)